#include "Fraccion.h"
using std::stringstream;

Fraccion::Fraccion(int dividendo, int divisor) {

	this->dividendo = dividendo;
	this->divisor = divisor;
}

int Fraccion::getDividendo() const {

	return this->dividendo;
}

void Fraccion::setDividendo(int dividendo) {

	this->dividendo = dividendo;
}

int Fraccion::getDivisor() const {

	return this->divisor;
}

void Fraccion::setDivisor(int divisor) {

	this->divisor = divisor;
}

string Fraccion::toString() const {

	stringstream s;

	s << this->dividendo << "/" << this->divisor;

	return s.str();
}

double Fraccion::evaluar() {

	try {

		if (divisor != 0) {

			return (double) dividendo / divisor;
		
		} else {

			throw divisor;
		}

	} catch (int e) {

		std::cout << "Error! Divisor es ";
		return 0;
	}
}

void Fraccion::simplificar() {

	int mcd = 1, aux = 0, a = dividendo, b = divisor;

	if (a < b) { // Para determinar el mayor

		aux = a;
		a = b;
		b = aux;
	}

	for (int i = 2; i <= b; i++) {

		if ((a % i == 0) && (b & i == 0)) {

			mcd = i;
		}
	}

	dividendo /= mcd;
	divisor /= mcd;
}

Fraccion operator + (const Fraccion& f1, const Fraccion& f2) {

	if (f1.getDivisor() == f2.getDivisor()) { // Caso de fraccion homogenea

		return Fraccion(f1.getDividendo() + f2.getDividendo(), f1.getDivisor());

	}
	else { // Caso de fraccion heterogenea

		return Fraccion(f1.getDividendo() * f2.getDivisor() + f1.getDivisor() * f2.getDividendo(), f1.getDivisor() * f2.getDivisor());
	}
}

Fraccion operator - (const Fraccion& f1, const Fraccion& f2) {

	if (f1.getDivisor() == f2.getDivisor()) { // Caso de fraccion homogenea

		return Fraccion(f1.getDividendo() - f2.getDividendo(), f1.getDivisor());

	}
	else { // Caso de fraccion heterogenea

		return Fraccion(f1.getDividendo() * f2.getDivisor() - f1.getDivisor() * f2.getDividendo(), f1.getDivisor() * f2.getDivisor());
	}
}

Fraccion operator / (const Fraccion& f1, const Fraccion& f2) {

	return Fraccion(f1.getDividendo() * f2.getDivisor(), f1.getDivisor() * f2.getDividendo());
}

Fraccion operator * (const Fraccion& f1, const Fraccion& f2) {

	return Fraccion(f1.getDividendo() * f2.getDividendo(), f1.getDivisor() * f2.getDivisor());
}

ostream& operator << (ostream& out, const Fraccion& f1) {

	out << f1.toString();
	return out;
}
