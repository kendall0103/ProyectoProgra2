#pragma once
#include <iostream>
#include <sstream>
using std::ostream;
using std::string;

class Fraccion {

private:

	int dividendo;
	int divisor;

public:

	Fraccion(int, int);
	int getDividendo() const;
	void setDividendo(int);
	int getDivisor() const;
	void setDivisor(int);
	string toString() const;
	double evaluar();
	void simplificar();

	// Sobrecargas
	friend Fraccion operator + (const Fraccion& f1, const Fraccion& f2);
	friend Fraccion operator - (const Fraccion& f1, const Fraccion& f2);
	friend Fraccion operator / (const Fraccion& f1, const Fraccion& f2);
	friend Fraccion operator * (const Fraccion& f1, const Fraccion& f2);
	friend ostream& operator << (ostream& out, const Fraccion& f1);

};