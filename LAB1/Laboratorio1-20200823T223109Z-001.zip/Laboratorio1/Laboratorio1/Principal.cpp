#include "Fraccion.h"
using std::cout;

int main() {

	Fraccion f1(8, 9);
	Fraccion f2(5, 3);
	Fraccion f3(2, 6);
	Fraccion f4(1, 0);

	cout << "Fracciones a utilizar:\n";
	cout << "\nF1 = " << f1;
	cout << "\nF2 = " << f2;
	cout << "\nF3 = " << f3;
	cout << "\nF4 = " << f4;

	cout << "\n\nOperaciones:\n\n";

	Fraccion suma = f1 + f2;
	suma.simplificar();
	cout << "F1 + F2 = " << suma << " = " << suma.evaluar() << "\n";

	Fraccion resta = f3 - f2;
	resta.simplificar();
	cout << "F3 - F2 = " << resta << " = " << resta.evaluar() << "\n";

	Fraccion division = f4 / f1;
	division.simplificar();
	cout << "F4 / F1 = " << division << " = ";
	cout << division.evaluar() << "\n";

	Fraccion multiplicacion = f1 * f3;
	multiplicacion.simplificar();
	cout << "F1 * F3 = " << multiplicacion << " = " << multiplicacion.evaluar() << "\n";

	cout << "\n";
	system("pause");
}